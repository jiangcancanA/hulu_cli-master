import CRender from './class/crender.class'

import {
	extendNewGraph
} from './config/graphs'


export default {
	CRender,
	extendNewGraph
}
